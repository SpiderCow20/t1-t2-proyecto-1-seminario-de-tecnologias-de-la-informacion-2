import * as THREE from 'three';
import { OrbitControls } from 'three/addons/controls/OrbitControls.js';

export class SceneSetup {
    constructor() {
        this.scene = null;
        this.camera = null;
        this.renderer = null;
        this.controls = null;
    }
    
    init() {
        // Crear escena
        this.scene = new THREE.Scene();
        
        // Color de fondo o niebla para ambiente acuático
        this.scene.background = new THREE.Color(0x0a1628);
        this.scene.fog = new THREE.FogExp2(0x0a1628, 0.003);
        
        // Configurar cámara
        this.camera = new THREE.PerspectiveCamera(
            60, // FOV
            window.innerWidth / window.innerHeight,
            0.1,
            100
        );
        this.camera.position.set(12, 8, 18);
        this.camera.lookAt(0, 0, 0);
        
        // Configurar renderer
        this.renderer = new THREE.WebGLRenderer({ 
            antialias: true,
            alpha: false
        });
        this.renderer.setSize(window.innerWidth, window.innerHeight);
        this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
        this.renderer.shadowMap.enabled = true;
        this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
        document.body.appendChild(this.renderer.domElement);
        
        // Controles de órbita
        this.controls = new OrbitControls(this.camera, this.renderer.domElement);
        this.controls.enableDamping = true;
        this.controls.dampingFactor = 0.05;
        this.controls.minDistance = 5;
        this.controls.maxDistance = 35;
        this.controls.maxPolarAngle = Math.PI * 0.7;
        this.controls.target.set(0, 0, 0);
        
        // Luces
        this.setupLights();
        
        // Entorno
        this.setupEnvironment();
        
        // Event listeners
        window.addEventListener('resize', this.onWindowResize.bind(this));
        
        return this;
    }
    
    setupLights() {
        // Luz ambiental (simula luz difusa submarina)
        const ambientLight = new THREE.AmbientLight(0x406080, 0.6);
        this.scene.add(ambientLight);
        
        // Luz hemisférica (cielo/agua)
        const hemisphereLight = new THREE.HemisphereLight(
            0x88aacc, // Color cielo/agua superficial
            0x223344, // Color profundo
            0.4
        );
        this.scene.add(hemisphereLight);
        
        // Luz direccional principal (simula rayos de sol penetrando el agua)
        const directionalLight = new THREE.DirectionalLight(0xaaccff, 0.8);
        directionalLight.position.set(10, 20, -5);
        directionalLight.castShadow = true;
        directionalLight.shadow.camera.near = 0.5;
        directionalLight.shadow.camera.far = 50;
        directionalLight.shadow.camera.left = -20;
        directionalLight.shadow.camera.right = 20;
        directionalLight.shadow.camera.top = 20;
        directionalLight.shadow.camera.bottom = -20;
        directionalLight.shadow.mapSize.width = 1024;
        directionalLight.shadow.mapSize.height = 1024;
        this.scene.add(directionalLight);
        
        // Luces puntuales para crear ambiente submarino
        const pointLight1 = new THREE.PointLight(0x4488cc, 0.5, 20);
        pointLight1.position.set(-5, 3, 5);
        this.scene.add(pointLight1);
        
        const pointLight2 = new THREE.PointLight(0x336699, 0.3, 15);
        pointLight2.position.set(5, -2, -5);
        this.scene.add(pointLight2);
    }
    
    setupEnvironment() {
        // Suelo oceánico
        const floorGeometry = new THREE.PlaneGeometry(40, 40, 20, 20);
        const floorMaterial = new THREE.MeshStandardMaterial({
            color: 0x2a3a4a,
            roughness: 0.8,
            metalness: 0.2,
            wireframe: false
        });
        const floor = new THREE.Mesh(floorGeometry, floorMaterial);
        floor.rotation.x = -Math.PI / 2;
        floor.position.y = -10;
        floor.receiveShadow = true;
        this.scene.add(floor);
        
        // "Techo" de agua (superficie simulada)
        const surfaceGeometry = new THREE.PlaneGeometry(40, 40);
        const surfaceMaterial = new THREE.MeshPhongMaterial({
            color: 0x6699cc,
            transparent: true,
            opacity: 0.3,
            side: THREE.DoubleSide
        });
        const surface = new THREE.Mesh(surfaceGeometry, surfaceMaterial);
        surface.rotation.x = -Math.PI / 2;
        surface.position.y = 8;
        this.scene.add(surface);
        
        // Rocas decorativas
        this.addDecorations();
    }
    
    addDecorations() {
        // Algunas rocas en el fondo
        const rockGeometry = new THREE.IcosahedronGeometry(1, 1);
        const rockMaterial = new THREE.MeshStandardMaterial({
            color: 0x556677,
            roughness: 0.9,
            metalness: 0.1
        });
        
        for (let i = 0; i < 8; i++) {
            const rock = new THREE.Mesh(rockGeometry, rockMaterial);
            rock.position.set(
                (Math.random() - 0.5) * 25,
                -9 - Math.random() * 2,
                (Math.random() - 0.5) * 25
            );
            rock.scale.set(
                0.5 + Math.random() * 1.5,
                0.3 + Math.random() * 0.7,
                0.5 + Math.random() * 1.5
            );
            rock.rotation.set(
                Math.random() * Math.PI,
                Math.random() * Math.PI,
                Math.random() * Math.PI
            );
            rock.castShadow = true;
            rock.receiveShadow = true;
            this.scene.add(rock);
        }
        
        // Partículas flotantes (plancton/partículas en el agua)
        const particlesGeometry = new THREE.BufferGeometry();
        const particlesCount = 500;
        const positions = new Float32Array(particlesCount * 3);
        
        for (let i = 0; i < particlesCount; i++) {
            positions[i * 3] = (Math.random() - 0.5) * 30;
            positions[i * 3 + 1] = (Math.random() - 0.5) * 16;
            positions[i * 3 + 2] = (Math.random() - 0.5) * 30;
        }
        
        particlesGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
        
        const particlesMaterial = new THREE.PointsMaterial({
            color: 0xaaccff,
            size: 0.05,
            transparent: true,
            opacity: 0.6,
            blending: THREE.AdditiveBlending
        });
        
        const particles = new THREE.Points(particlesGeometry, particlesMaterial);
        this.scene.add(particles);
    }
    
    onWindowResize() {
        this.camera.aspect = window.innerWidth / window.innerHeight;
        this.camera.updateProjectionMatrix();
        this.renderer.setSize(window.innerWidth, window.innerHeight);
    }
    
    render() {
        this.renderer.render(this.scene, this.camera);
    }
}