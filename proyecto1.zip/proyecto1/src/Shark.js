import * as THREE from 'three';

export class Shark {
    constructor(position = new THREE.Vector3(0, 0, 0), rotation = new THREE.Euler(0, 0, 0)) {
        // Propiedades de movimiento
        this.velocity = new THREE.Vector3(0, 0, 1);
        this.speed = 0.05 + Math.random() * 0.1; // Velocidad variable entre agentes
        this.rotationSpeed = 0.02;
        this.bounds = {
            x: 15, y: 8, z: 15  // Límites de la escena
        };
        
        // Crear el mesh del tiburón
        this.mesh = this.createSharkMesh();
        this.mesh.position.copy(position);
        this.mesh.rotation.copy(rotation);
        
        // Inicializar dirección basada en rotación
        this.updateDirection();
    }
    
    createSharkMesh() {
        const group = new THREE.Group();
        
        // Materiales
        const bodyMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x4a6fa5,
            specular: 0x222222,
            shininess: 30
        });
        const bellyMaterial = new THREE.MeshPhongMaterial({ 
            color: 0xb0c4de,
            specular: 0x111111,
            shininess: 10
        });
        const eyeMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x000000 
        });
        const finMaterial = new THREE.MeshPhongMaterial({ 
            color: 0x3a5f95,
            specular: 0x222222,
            shininess: 30
        });
        
        // Cuerpo principal (elipsoide alargado)
        const bodyGeo = new THREE.ConeGeometry(0.4, 1.5, 8, 16);
        const body = new THREE.Mesh(bodyGeo, bodyMaterial);
        body.rotation.x = Math.PI / 2; // Rotar para que apunte hacia adelante
        group.add(body);
        
        // Vientre (cilindro blanco para contraste)
        const bellyGeo = new THREE.CylinderGeometry(0.15, 0.15, 1.2, 8);
        const belly = new THREE.Mesh(bellyGeo, bellyMaterial);
        belly.position.y = -0.1;
        belly.rotation.x = Math.PI / 2;
        group.add(belly);
        
        // Cabeza (cono para la nariz)
        const headGeo = new THREE.ConeGeometry(0.25, 0.6, 8);
        const head = new THREE.Mesh(headGeo, bodyMaterial);
        head.position.z = 0.95;
        head.rotation.x = Math.PI / 2;
        group.add(head);
        
        // Aleta dorsal
        const dorsalFinGeo = new THREE.ConeGeometry(0.2, 0.5, 4);
        const dorsalFin = new THREE.Mesh(dorsalFinGeo, finMaterial);
        dorsalFin.position.y = 0.35;
        dorsalFin.position.z = -0.1;
        dorsalFin.rotation.z = Math.PI / 6;
        group.add(dorsalFin);
        
        // Aletas pectorales (izquierda y derecha)
        const pectoralFinGeo = new THREE.ConeGeometry(0.1, 0.4, 4);
        
        const leftFin = new THREE.Mesh(pectoralFinGeo, finMaterial);
        leftFin.position.set(-0.3, -0.1, 0.2);
        leftFin.rotation.set(0, 0, -Math.PI / 3);
        group.add(leftFin);
        
        const rightFin = new THREE.Mesh(pectoralFinGeo, finMaterial);
        rightFin.position.set(0.3, -0.1, 0.2);
        rightFin.rotation.set(0, 0, Math.PI / 3);
        group.add(rightFin);
        
        // Cola (aleta caudal)
        const tailGeo = new THREE.ConeGeometry(0.1, 0.5, 4);
        const tail = new THREE.Mesh(tailGeo, finMaterial);
        tail.position.z = -0.85;
        tail.rotation.x = Math.PI / 2;
        tail.scale.set(0.5, 1, 1); // Aplanar para que parezca aleta
        group.add(tail);
        
        // Ojos
        const eyeGeo = new THREE.SphereGeometry(0.05, 8, 8);
        
        const leftEye = new THREE.Mesh(eyeGeo, eyeMaterial);
        leftEye.position.set(-0.18, 0.05, 0.85);
        group.add(leftEye);
        
        const rightEye = new THREE.Mesh(eyeGeo, eyeMaterial);
        rightEye.position.set(0.18, 0.05, 0.85);
        group.add(rightEye);
        
        // Ajustar orientación general para que el tiburón "nade" en Z positivo
        group.rotation.x = -Math.PI / 2;
        
        return group;
    }
    
    updateDirection() {
        // La dirección local es el eje Z (hacia adelante)
        const direction = new THREE.Vector3(0, 0, 1);
        direction.applyQuaternion(this.mesh.quaternion);
        this.velocity.copy(direction).multiplyScalar(this.speed);
    }
    
    update() {
        // Movimiento básico: avanzar en dirección local
        this.mesh.position.add(this.velocity);
        
        // Añadir pequeña rotación aleatoria para movimiento orgánico
        this.mesh.rotateY((Math.random() - 0.5) * this.rotationSpeed);
        this.mesh.rotateX((Math.random() - 0.5) * this.rotationSpeed * 0.3);
        this.mesh.rotateZ((Math.random() - 0.5) * this.rotationSpeed * 0.2);
        
        // Actualizar dirección después de la rotación
        this.updateDirection();
        
        // Verificar límites y reaparecer si es necesario
        this.checkBounds();
    }
    
    checkBounds() {
        const pos = this.mesh.position;
        let outOfBounds = false;
        
        // Verificar si salió de los límites
        if (Math.abs(pos.x) > this.bounds.x || 
            Math.abs(pos.y) > this.bounds.y || 
            Math.abs(pos.z) > this.bounds.z) {
            outOfBounds = true;
        }
        
        if (outOfBounds) {
            this.respawn();
        }
    }
    
    respawn() {
        // Reaparecer en un punto aleatorio dentro de los límites
        this.mesh.position.set(
            (Math.random() - 0.5) * this.bounds.x * 1.8,
            (Math.random() - 0.5) * this.bounds.y * 1.8,
            (Math.random() - 0.5) * this.bounds.z * 1.8
        );
        
        // Nueva orientación aleatoria
        this.mesh.rotation.set(
            Math.random() * Math.PI * 2,
            Math.random() * Math.PI * 2,
            Math.random() * Math.PI * 0.5
        );
        
        // Actualizar velocidad y dirección
        this.speed = 0.05 + Math.random() * 0.1;
        this.updateDirection();
    }
    
    reset() {
        this.respawn();
    }
}