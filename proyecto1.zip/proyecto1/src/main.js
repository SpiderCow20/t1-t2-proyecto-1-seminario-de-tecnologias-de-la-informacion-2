import * as THREE from 'three';
import { SceneSetup } from './SceneSetup.js';
import { Shark } from './Shark.js';

class SharkSwarm {
    constructor() {
        this.sceneSetup = new SceneSetup();
        this.sceneSetup.init();
        
        this.sharks = [];
        this.clock = new THREE.Clock();
        
        // Crear agentes
        this.createSharks(8); // Mínimo 5, usamos 8 para mejor visualización
        
        // Iniciar loop de animación
        this.animate();
        
        // Event listener para tecla R
        window.addEventListener('keydown', (event) => {
            if (event.key === 'r' || event.key === 'R') {
                this.resetSharks();
            }
        });
    }
    
    createSharks(count) {
        const bounds = { x: 15, y: 8, z: 15 };
        
        for (let i = 0; i < count; i++) {
            // Posición aleatoria inicial
            const position = new THREE.Vector3(
                (Math.random() - 0.5) * bounds.x * 1.5,
                (Math.random() - 0.5) * bounds.y * 1.5,
                (Math.random() - 0.5) * bounds.z * 1.5
            );
            
            // Rotación aleatoria inicial
            const rotation = new THREE.Euler(
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 2,
                Math.random() * Math.PI * 0.5
            );
            
            const shark = new Shark(position, rotation);
            this.sharks.push(shark);
            this.sceneSetup.scene.add(shark.mesh);
        }
        
        console.log(`${count} tiburones creados exitosamente`);
    }
    
    resetSharks() {
        console.log('Reiniciando posiciones de tiburones...');
        this.sharks.forEach(shark => {
            shark.reset();
        });
    }
    
    animate() {
        requestAnimationFrame(this.animate.bind(this));
        
        const deltaTime = this.clock.getDelta();
        // Limitar delta time para evitar saltos grandes
        const safeDelta = Math.min(deltaTime, 0.1);
        
        // Actualizar cada tiburón
        this.sharks.forEach(shark => {
            shark.update();
        });
        
        // Actualizar controles
        this.sceneSetup.controls.update();
        
        // Renderizar
        this.sceneSetup.render();
    }
}

// Iniciar aplicación
const app = new SharkSwarm();

// Log de confirmación
console.log('Proyecto de Enjambre de Tiburones - Entrega 1');
console.log('Controles: Click+Arrastrar = Rotar | Scroll = Zoom | R = Reiniciar');